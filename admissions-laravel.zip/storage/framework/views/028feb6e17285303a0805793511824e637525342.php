 
   
<?php $__env->startSection('style'); ?>
 
        <script src="<?php echo url('public/assets/js/jquery.min.js'); ?>"></script>
 
        <script src="<?php echo url('public/assets/js/jquery-ui.min.js'); ?>"></script>
 
<style>
     
</style>
<?php $__env->stopSection(); ?>
 <?php $__env->startSection('content'); ?>
  <?php $sys = app('App\Http\Controllers\SystemController'); ?>
 <div align="center">
     <h3 class="uk-text-bold uk-text-danger">Allow pop ups on your browser please!!!!!</h3>
     <p class="uk-text-primary uk-text-bold uk-text-small">Hotlines 0505284060 (Gad), 0246091283(Kojo),0276363053(Timo)</p>
  <h5 > Fee Payment  for <?php echo $sem; ?> Semester  | <?php echo $year; ?> Academic Year</h5>
             <hr>
             
             <form method="POST" action="<?php echo e(url('processPayment')); ?>" accept-charset="utf-8"  name="applicationForm"  v-form>
                 <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>"> 
            
                  <div align="center">
                    <legend align=" " class="style1">Personal Records of <?php echo @$data[0]->TITLE.@$data[0]->NAME; ?></legend>
                  </div>
      <div class="uk-width-large-1-2">
              
                 <div class="md-card">
                     <div class="md-card-content">
                      <table ><tr>
         
                     <td>
                      <table  class="uk-table uk-table-nowrap "  border="0">
                        <tr>
                            <td width="495"><div class="divcurve" style=" ">



                                    <table   class="">
                                         <tr>
                                            <td  align=""> <div  align="right" >Receipt No</div></td>
                                        <td>
                                            <?php echo e($receipt); ?>

                                            <input type="hidden" name="receipt"   value="<?php echo e($receipt); ?>" />
                                            <input type="hidden" name="stno"   value="<?php echo e($data[0]->STNO); ?>" />
                                            
                                        </td>
                                        </tr>
                                        <?php if($data[0]->YEAR==1): ?>
                                        <tr>
                                            <td  align=""> <div  align="right" >Admission Number</div></td>
                                        <td>
                                            <?php echo e($data[0]->STNO); ?>

                                             
                                        </td>
                                        </tr>
                                         <?php else: ?>
                                          <tr>
                                            <td  align=""> <div  align="right" >Index Number</div></td>
                                        <td>
                                            <?php echo e($data[0]->INDEXNO); ?>

                                             
                                        </td>
                                        </tr>
                                        <?php endif; ?>
                                        <tr>
                                            <td  align=""> <div  align="right" >Full Name</div></td>
                                        <td>
                                            <?php echo e($data[0]->NAME); ?>

                                            <input type="hidden" name="student" id="student" value="<?php echo e($data[0]->INDEXNO); ?>" />
                                            
                                        </td>
                                        </tr>
                                        <tr>
                                            <td  align=""> <div  align="right" >Level</div></td>
                                        <td>
                                            <?php echo e($data[0]->LEVEL); ?>

                                              
                                        </td>
                                        </tr>
                                        <tr>
                                            <td  align=""> <div  align="right" >Programme</div></td>
                                        <td>
                                            <?php echo e(@$sys->getProgram($data[0]->PROGRAMMECODE)); ?>

                                             <input type="hidden" name="programme"  value="<?php echo e($data[0]->PROGRAMMECODE); ?>" />
                                           
                                        </td>
                                        </tr>
                                        <tr>
                                            <td align=""> <div  align="right" class="uk-text-success">Phone N<u>o</u></div></td>
                                        <td>
                                          
                                            <input type="text" class="md-input" maxlength="10" min="10"  name="phone" value="<?php echo e($data[0]->TELEPHONENO); ?>"/>
                                      
                                        </td>
                                        </tr>
                                        <tr>
                                            <td  align=""> <div  align="right" class="uk-text-success">Update Level/Year</div></td>
                                        <td>
                                          
                                              <?php echo Form::select('level', array('1'=>'1st years','2' => '2nd years', '3' => '3rd years','4' => '4th years','400/1'=>'BTECH top up level 1','400/2'=>'BTECH topup level 2'), null, ['placeholder' => 'select level','required'=>'','class'=>'md-input parent','v-model'=>'level','v-form-ctrl'=>'','v-select'=>''],old("level",""));; ?>

                                              <p class="uk-text-danger uk-text-small"  v-if="applicationForm.level.$error.required" >Level is required</p>

                                        </td>
                                        </tr>
                                        <tr>
                                            <td  align=""> <div  align="right" class="uk-text-danger">CURRENT  BILLS</div></td>
                                        <td>
                                          GHC  <?php echo e($data[0]->BILLS); ?>

                                            <input type="hidden" id="bill" onkeyup="recalculateSum();" name="bill" value="<?php echo e($data[0]->BILL_OWING); ?>"/>
                                      
                                        </td>
                                        </tr>
                                          
                                         
                                         <tr>
                                            <td  align=""> <div  align="right" class="uk-text-primary">TOTAL BILL OWING </div></td>
                                        <td>
                                          GHC  <?php echo e($data[0]->BILL_OWING); ?>

                                            </td>
                                        </tr>
                                         <tr>
                                            <td  align=""> <div  align="right" class="uk-text-success">Amount Paying GHC</div></td>
                                        <td>
                                            <input type="text" id="pay" required=""  onkeyup="recalculateSum();"  v-model="amount" v-form-ctrl=""  name="amount"   class="md-input">
                                             <p class="uk-text-danger uk-text-small"  v-if="applicationForm.amount.$error.required" >Payment amount is required</p>

                                            
                                        </td>
                                        </tr>
                                        
                                        <tr>
                                            <td  align=""> <div  align="right" class="uk-text-success">Previous owing (if any) GHC</div></td>
                                        <td>
                                            <input type="text"     name="prev-owing"   class="md-input">
                                            
                                            
                                        </td>
                                        </tr>
                                        
                                        
                                        
                                        <tr>
                                            <td align=""> <div  align="right" class="uk-text-primary">Balance GHC</div></td>
                                        <td>
                                            <input type="text"  disabled=""    id="amount_left" onkeyup="recalculateSum();" readonly="readonly"   class="md-input">
                                          
                                            
                                            
                                        </td>
                                        </tr>
                                         <tr>
                                            <td  align=""> <div  align="right" >Date of Payment at bank</div></td>
                                        <td>
                                            <input type="text" required=""  data-uk-datepicker="{format:'DD/MM/YYYY'}" v-model="bank_date" v-form-ctrl=""     name="bank_date"  class="md-input">
                                          
                                            
                                             <p class="uk-text-danger uk-text-small"  v-if="applicationForm.bank_date.$error.required" >Bank date is required</p>

                                        </td>
                                        </tr>
                                         
                                         <tr>
                                            <td  align=""> <div  align="right" class=" ">Bank Account</div></td>
                                        <td>
                                           <?php echo Form::select('bank', 
                                            (['' => 'Select bank account ']+$banks ), 
                                                null, 
                                                ['required'=>'','class' => 'md-input','v-model'=>'bank','v-form-ctrl'=>'','v-select'=>''] ); ?>



                                             <p class="uk-text-danger uk-text-small"  v-if="applicationForm.bank.$error.required" >Bank  is required</p>

                                        </td>
                                        </tr>
                                          
                                        <tr>
                                            <td  align=""> <div  align="right" class=" ">Payment Type</div></td>
                                        <td>
                                            <select name="payment_detail" required="" class="md-input" v-form-ctrl='' v-model='payment_detail' v-select=''>
                                                <option>Select payment type</option>
                                                <option value="PAY IN SLIP">PAY IN SLIP</option>
                                                 
                                                <option value="Bursery">Bursery</option>
                                                <option value="Receipt">Receipt</option>
                                                <option value="Scholarship">Scholarship</option>
                                            </select>
                                             <p class="uk-text-danger uk-text-small"  v-if="applicationForm.payment_detail.$error.required" >Payment type is required</p>

                                            
                                        </td>
                                        </tr>
                                    </table>
                                </div>
                            </td></tr>
                        
                                        
                         
                                     </table>
                        
                         
                         
                     </td>
                            <td valign="top" >
                     <img   style="width:150px;height: auto;"  <?php
                                     $pic = $data[0]->INDEXNO;
                                     echo $sys->picture("{!! url(\"public/albums/students/$pic.jpg\") !!}", 90)
                                     ?>   src='<?php echo e(url("public/albums/students/$pic.jpg")); ?>' alt="  Affix student picture here"    />
             </td>
                              
                          </tr>
                      </table>
                    </div>
                    </div>
                </div>
                 <p></p>
                 <div class="uk-grid" align='center'>
                     <div class="uk-width-1-1">
                         <button  v-show="applicationForm.$valid" type="submit" class="md-btn md-btn-primary"><i class="fa fa-save" ></i>Accept</button>
                     </div>
                 </div>

             </form>
             
 </div>
  
 <?php $__env->stopSection(); ?>
 
<?php $__env->startSection('js'); ?>
 <script src="<?php echo url('public/assets/js/select2.full.min.js'); ?>"></script>
<script>
$(document).ready(function(){
  $('select').select2({ width: "resolve" });

  
});


</script>
  <script>


//code for ensuring vuejs can work with select2 select boxes
Vue.directive('select', {
  twoWay: true,
  priority: 1000,
  params: [ 'options'],
  bind: function () {
    var self = this
    $(this.el)
      .select2({
        data: this.params.options,
         width: "resolve"
      })
      .on('change', function () {
        self.vm.$set(this.name,this.value)
        Vue.set(self.vm.$data,this.name,this.value)
      })
  },
  update: function (newValue,oldValue) {
    $(this.el).val(newValue).trigger('change')
  },
  unbind: function () {
    $(this.el).off().select2('destroy')
  }
})


var vm = new Vue({
  el: "body",
  ready : function() {
  },
 data : {
   
   
 options: [    ]  
    
  },
   
})

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>