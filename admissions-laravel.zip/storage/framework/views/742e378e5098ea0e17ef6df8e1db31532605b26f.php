<?php $__env->startSection('content'); ?>

 
      
                    <?php $sys = app('App\Http\Controllers\SystemController'); ?>
                   
          <div class="uk-width-xL">            
                      <div class="uk-overflow-container" id='print'>
                            <center> <p>Course:<b> <?php echo $course; ?></b> |  Total Students = <b> <?php echo $total; ?>  |  Academic Year = <b> <?php echo $year; ?> |  Semester = <b> <?php echo $sem; ?> sem</center></p>
     
                 <table   class="uk-table uk-table-hover uk-table-align-vertical uk-table-nowrap tablesorter tablesorter-altair" id="ts_pager_filter"> 
             
               <thead>
                 <tr>
                     <th>N<u>o</u></th>
                     
                     <th  style="text-align:">Photo</th>
                      
                      <th>Index N<u>o</u></th>
                     <th style="text-align:">Name</th>
                     <th style="text-align:center">Signature</th>
                     
                      
                                      
                </tr>
             </thead>
             <tbody>
                                        
                             <?php foreach($mark as $index=> $row): ?> 



                            <tr align="">
                                <td> <?php echo e($mark->perPage()*($mark->currentPage()-1)+($index+1)); ?> </td>
                                <td><img class="md-user-image-large" style="width:60px;height: auto" src="<?php echo url('Albums/students/'.$sys->getStudentByID($row->student).'.JPG'); ?>" alt=" Picture of Student Here"    /></td>

                                <td class="uk-text-success"> <?php echo e(@$sys->getStudentByID($row->student)); ?></td>
                                <td class="uk-text-primary"> <?php echo e(@$sys->getStudentNameByID($row->student)); ?></td>
                                <td>.................................</td>
 
                            </tr>
                             <?php endforeach; ?>
                        </tbody>
                                    
                             </table>
           
     </div>
  
          </div>
                 
                
      
 
 
        
 <?php $__env->stopSection(); ?>
 
<?php $__env->startSection('js'); ?>
 <script type="text/javascript">
  
$(document).ready(function(){
window.print();
//window.close();
});

</script>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.printlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>