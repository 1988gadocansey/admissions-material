 
<?php $__env->startSection('style'); ?>
 
<?php $__env->stopSection(); ?>
 <?php $__env->startSection('content'); ?>
  
   <div class="md-card-content">
        
 <?php if($messages=Session::get("success")): ?>

    <div class="uk-form-row">
        <div style="text-align: center" class="uk-alert uk-alert-success" data-uk-alert="">

              <ul>
                <?php foreach(@$messages as $message): ?>
                  <li> <?php echo $message; ?> </li>
                <?php endforeach; ?>
          </ul>
    </div>
  </div>
<?php endif; ?>
 
  
            
 <?php if($messages=Session::get("error")): ?>

    <div class="uk-form-row">
        <div style="text-align: center" class="uk-alert uk-alert-danger" data-uk-alert="">

              <ul>
                <?php foreach(@$messages as $message): ?>
                  <li> <?php echo $message; ?> </li>
                <?php endforeach; ?>
          </ul>
    </div>
  </div>
<?php endif; ?>
 
 </div>
 <div style="">
     <div class="uk-margin-bottom" style="margin-left:900px" >
         <a  href="#new_task" data-uk-modal="{ center:true }"> <i title="click to send sms to students owing"   class="material-icons md-36 uk-text-success"   >phonelink_ring message</i></a>

         <a href="#" class="md-btn md-btn-small md-btn-success uk-margin-right" id="printTable">Print Table</a>
         <div class="uk-button-dropdown" data-uk-dropdown="{mode:'click'}">
             <button class="md-btn md-btn-small md-btn-success"> columns <i class="uk-icon-caret-down"></i></button>
             <div class="uk-dropdown">
                 <ul class="uk-nav uk-nav-dropdown" id="columnSelector"></ul>
             </div>
         </div>
     </div>
 </div>
 <!-- filters here -->
  <?php $fee = app('App\Http\Controllers\FeeController'); ?>
   <?php $sys = app('App\Http\Controllers\SystemController'); ?>
 <div class="uk-width-xLarge-1-1">
    <div class="md-card">
        <div class="md-card-content">
            
                <form action="<?php echo url('view_fees'); ?>"  method="get" accept-charset="utf-8" novalidate id="group">
                   <?php echo csrf_field(); ?>

                    <div class="uk-grid" data-uk-grid-margin="">

                        <div class="uk-width-medium-1-5">
                            <div class="uk-margin-small-top">
                                    <?php echo Form::select('program', 
                                (['' => 'All programs'] +$program ), 
                                  old("program",""),
                                    ['class' => 'md-input parent','id'=>"parent",'placeholder'=>'select program'] ); ?>

                         </div>
                        </div>
                        <div class="uk-width-medium-1-5">
                            <div class="uk-margin-small-top">
                               <?php echo Form::select('level', array('50'=>'50','100'=>'1st years','200' => '2nd years', '300' => '3rd years','400'=>'4th years'), null, ['placeholder' => 'select level','id'=>'parent','class'=>'md-input parent'],old("level",""));; ?>

                              </div>
                        </div>
                        
                        <div class="uk-width-medium-1-5">
                            <div class="uk-margin-small-top">
                                    <?php echo Form::select('year', 
                                (['' => 'Select year'] +$year ), 
                                  old("year",""),
                                    ['class' => 'md-input parent','id'=>"parent"] ); ?>

                         </div>
                        </div>
                        
                          
                         

                       
                           <div class="uk-width-medium-1-10" style=" ">
                            <div class="uk-margin-small-top">  
                            <div class="uk-button-dropdown" data-uk-dropdown="{mode:'click'}">
                                <button class="md-btn md-btn-small md-btn-success uk-margin-small-top">Export <i class="uk-icon-caret-down"></i></button>
                                <div class="uk-dropdown">
                                    <ul class="uk-nav uk-nav-dropdown">
                                         <li><a href="#" onClick ="$('#ts_pager_filter').tableExport({type:'csv',escape:'false'});"><img src='<?php echo url("assets/icons/csv.png"); ?>' width="24"/> CSV</a></li>
                                           
                                            <li class="uk-nav-divider"></li>
                                            <li><a href="#" onClick ="$('#ts_pager_filter').tableExport({type:'excel',escape:'false'});"><img src='<?php echo url("assets/icons/xls.png"); ?>' width="24"/> XLS</a></li>
                                            <li><a href="#" onClick ="$('#ts_pager_filter').tableExport({type:'doc',escape:'false'});"><img src='<?php echo url("assets/icons/word.png"); ?>' width="24"/> Word</a></li>
                                            <li><a href="#" onClick ="$('#ts_pager_filter').tableExport({type:'powerpoint',escape:'false'});"><img src='<?php echo url("assets/icons/ppt.png"); ?>' width="24"/> PowerPoint</a></li>
                                            <li class="uk-nav-divider"></li>
                                           
                                    </ul>
                                </div>
                            </div>
                        </div>
                           </div>
                            
                        <div class="uk-width-medium-1-10"  style="" >                            
                            <div class="uk-margin-small-top">
                                 <i title="click to print" onclick="javascript:printDiv('print')" class="material-icons md-36 uk-text-success"   >print</i>
                   
                            </div>
                          </div>
                         
                        
                        
                    
                    </div>
                   
                </form> 
        </div>
    </div>
 </div>
 <div class="uk-width-xLarge-1-1">
 <div class="md-card">
 <div class="md-card-content">
          <h5>Proposed Fees</h5>  
    
      
     <div class="uk-overflow-container">
           <center><span class="uk-text-success uk-text-bold"><?php echo $data->total(); ?> Records</span></center>
       
            <table class="uk-table uk-table-align-vertical uk-table-nowrap tablesorter tablesorter-altair" id="ts_pager_filter">                     <thead>
                     <thead>
                            <tr>
                                <th></th>
                                     <th>NO</th>
                                     <th>NAME</th> 
                                     <th>FEE TYPE</th> 
                                    
                                     <th>PROGRAMME</th>
                                      <th>LEVEL</th>
                                       <th >AMOUNT</th>
                                       <th>TOTAL STUDENTS</th>
                                       <th>PROPOSED AMOUNT</th>
                                      <th>SEMESTER</th>
                                      <th>YEAR</th> 
                                     
                                     <th>STUDENT TYPE</th>
                                     
                                      <th>SEASON TYPE</th>
                                      
                                       <th>ACTION</th>
                                           
                                           
                                        </tr>
                                    </thead>
                                    <tbody>
                                        
                                         <?php foreach($data as $index=> $row): ?> 
                                          
                                        <tr align="">
                                              <td><input type="checkbox" data-md-icheck class="ts_checkbox"></td>
                                            <td> <?php echo e($data->perPage()*($data->currentPage()-1)+($index+1)); ?> </td>
                                              
                                            <td> <?php echo e(@$row->NAME); ?></td> 
                                            <td> <?php echo e(@$row->FEE_TYPE); ?></td>
                                             <td><?php echo e(@$row->program->PROGRAMME); ?></td>
                                            <td> <?php echo e(@$row->LEVEL); ?></td>
                                             <td style="text-align: center"><span class="uk-text-success uk-text-bold"> <?php echo e(@$row->AMOUNT); ?></span></td>
                                          
                                            <td style="text-align: center"><span class="uk-text-success uk-text-bold"> <?php echo e(@$row->TOTALSTUDENTS); ?></span></td>
                                             <td style="text-align: center"><span class="uk-text-success uk-text-bold"> GHC <?php echo e(@$row->TOTALAMOUNT); ?></span></td>
                                            <td> <?php echo e(@$row->SEMESTER); ?></td>
                                             <td> <?php echo e(@$row->YEAR); ?></td> 
                                           
                                            <td> <?php echo e(@$row->NATIONALITY); ?></td>
                                           
                                            <td> <?php echo e(@$row->SEASON_TYPE); ?></td>
                                           
                                            <td>
     
                                                 <?php if($row->STATUS=='approved'): ?>
                                                  
                                                 <span class='uk-text-success'>Approved ready</span> 
                                                 
                                                 <?php else: ?>
                                                    
                                                    <?php echo Form::open(['action' => ['FeeController@destroy', 'id'=>$row->ID], 'method' => 'DELETE','name'=>'myform' ,'style' => 'display: inline;']); ?>


                                                   <button type="button" class="md-btn  md-btn-danger md-btn-small   md-btn-wave-light waves-effect waves-button waves-light" onclick="UIkit.modal.confirm('Are you sure you want to delete this fee?', function(){ document.forms[0].submit(); });"><i  class="sidebar-menu-icon material-icons md-18">delete</i></button>
                                                        <input type='hidden' name='fee' value='<?php echo e($row->ID); ?>'/>  
                                                     <?php echo Form::close(); ?>


                                                  <button title='click to approve fees' type="button" class="md-btn  md-btn-primary md-btn-small   md-btn-wave-light waves-effect waves-button waves-light" onclick="UIkit.modal.confirm('Are you sure you want to bill student with this fee item?', function(){   return window.location.href='run_bill/<?php echo $row->ID; ?>/id'     ; });"><i  class="sidebar-menu-icon material-icons md-18">done</i></button> 

                                                  <?php endif; ?>


                                                
                                            
                                            
                                            </td>
                                              
                                        </tr>
                                         <?php endforeach; ?>
                                    </tbody>
                                    
                             </table>
            <div style="margin-left: 1070px" class="uk-text-bold uk-text-success"><td colspan=" ">TOTAL PAID GHC<u>  <?php echo e($totalProposed); ?></u></td></div>
      
          <?php echo (new Landish\Pagination\UIKit($data->appends(old())))->render(); ?>

     </div>

 </div>
 </div></div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
 
   
 <script type="text/javascript">
      
$(document).ready(function(){
 
$(".parent").on('change',function(e){
 
   $("#group").submit();
 
});
});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>