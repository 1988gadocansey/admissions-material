<?php $__env->startSection('style'); ?>
  
 <link rel="stylesheet" href="<?php echo url('public/assets/bootstrap-material-datetimepicker.css'); ?>" media="all">  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col s12 m12 l12">
    <div class="card">
       
            <?php if(Session::has('success1')): ?>
             <div class="card-panel light-green lighten-3">
            <div style="text-align: center" class=" white-text alert  alert-success"   >
                <?php echo Session::get('success1'); ?> <a href="<?php echo e(url('form/step2')); ?>">Click to Move to Next Step</a>
            </div></div>
            <?php endif; ?>
             <?php if(Session::has('error1')): ?>
             <div class="card-panel red">
            <div style=" " class=" white-text alert  alert-success"  >
                <?php echo Session::get('error1'); ?>

            </div></div>
            <?php endif; ?>

            <?php if(count($errors) > 0): ?>

             <div class="card-content blue-grey">
                <div class=" alert  alert-danger  " style="background-color: red;color: white">

                    <ul>
                        <?php foreach($errors->all() as $error): ?>
                        <li> <?php echo e($error); ?> </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
            <?php endif; ?>
        </div> 
</div>
<main class="mn-inner container">
<div class="row">
    <div class="col s12">
        <div class="page-title  "> Step 2 - Form Filling  | YOUR APPLICATION NUMBER  <?php echo e(@\Auth::user()->FORM_NO); ?></div>
    </div>
    <div class="col s12 m12 l12">
        <div class="card hoverable">
            <div class="card-content">
                 <?php if(@\Auth::user()->STARTED=="1"): ?>
                <div style="float: right"><a class="waves-effect waves-green btn-flat m-b-xs" href="<?php echo e(url('/form/step3')); ?>">Next Step</a></div>
                <?php endif; ?>
               <form id="example-form"   v-form  method="post" accept-charset="utf-8"  name="applicationForm"    >
                    <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>"> 

                                    <div>
                                        <h3>Page 1 - Biodata</h3>
                                        <section>
                                            <div class="wizard-content">
                                                <div class="row">
                                                    <div class="col m6">
                                                        <div class="row">
                                                            <div class="input-field col m6 s12">
                                                                <label for="firstName">First name</label>
                                                                <input id="firstName" name="fname" type="text" value="<?php echo e($data->FIRSTNAME); ?>" class="required validate">
                                                            </div>
                                                            <div class="input-field col m6 s12">
                                                                <label for="lastName">Last name</label>
                                                                <input id="lastName" name="lname" value="<?php echo e($data->SURNAME); ?>" type="text" class="required validate">
                                                            </div>
                                                            <div class="input-field col s12">
                                                                <label for="email">Othernames</label>
                                                                <input id="oname" name="othernames" value="<?php echo e($data->OTHERNAME); ?>" type="text" class="">
                                                            </div>
                                                            <div class="input-field col s12">
                                                                <div class="input-field col m6 s12">
                                                        <?php echo Form::select('qualification',array("WASSCE"=>"WASSCE","SSCE"=>"SSCE","CERTIFICATE"=>"CERTIFICATE","TECHNICAL"=>"TECHNICAL SCHOOL"),old('qualification',''),array('placeholder'=>'SELECT QUALIFICATION',"required"=>"required", "tabindex"=>"-1")); ?>

                                                            </div>

                                                            </div>
                                                            <div class="input-field col s12">
                                                                <label for="confirm">Application Mode </label>
                                                                <input id="" readonly="" name="entry" type="text" value="<?php echo e(@\Auth::user()->FORM_TYPE); ?>" class="required validate">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col m6">
                                                        <div class="row">
                                                            <div class="input-field col m6 s12">
                                                        <?php echo Form::select('title',array("Mr"=>"Mr","Mrs"=>"Mrs","Miss"=>"Miss"),old($data->TITLE,''),array('placeholder'=>'Select title',"required"=>"required", "tabindex"=>"-1","v-model"=>"title","v-form-ctrl"=>"","id"=>"basic")); ?>

                                                            </div>
                                                             <div class="input-field col m6 s12">
                                                        <?php echo Form::select('gender',array("Male"=>"Male","Female"=>"Female"),old('gender',''),array('placeholder'=>'Select gender',"required"=>"required", "tabindex"=>"-1","v-model"=>"gender","v-form-ctrl"=>"","v-select"=>"gender","style"=>"width: 100%")); ?>

                                                            </div>
                                                            <div class="input-field col m6 s12">
                                                                <label for="birthdate">Date of Birth (Format 12/03/1990)</label>
                                                                <input id="birthdate" name="dob" type="date" placeholder="format 12/03/1990" class=" required">
                                                            </div>
                                                            <div class="input-field col m6 s12">
                                                               <?php echo Form::select('marital_status',array("Single"=>"Single","Married"=>"Married","Divorced"=>"Divorced"),old('marital_status',''),array('placeholder'=>'Select marital status',"required"=>"required", "tabindex"=>"-1","v-model"=>"tistle","v-form-ctrl"=>"","id"=>"bassic")); ?>

                                                         
                                                            </div>
                                                            <div class="input-field col s12">
                                                                <label for="phone">Phone number</label>
                                                                <input id="phone" name="phone" minlength="10" pattern='^[0-9]{10}$'  value="<?php echo e($data->PHONE); ?>"  maxlength="10"type="number" class="required validate">
                                                            </div>
                                                            <div class="input-field col s12">
                                                            <?php echo Form::select('session',array("Regular"=>"Regular","Weekend"=>"Weekend","Evening"=>"Evening"),old('session',''),array('placeholder'=>'Select session preference',"required"=>"required", "tabindex"=>"-1",)); ?>

                                                           
                                                            </div>
                                                        
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </section>
                                        <h3>Page 2 - Address and Location</h3>
                                        <section>
                                            <div class="wizard-content">
                                                  <div class="row">
                                                    <div class="col m6">
                                                        <div class="row">
                                                            <div class="input-field col m6 s12">
                                                                <label for="firstName">Hometown</label>
                                                                <input id="s" name="hometown" type="text" value="<?php echo e($data->HOMETOWN); ?>"class="required validate">
                                                            </div>
                                                            <div class="input-field col m6 s12">
                                                                <label for="lastName">Contact Address</label>
                                                                <input id="contact" name="contact" type="text" value="<?php echo e($data->ADDRESS); ?>" class="required validate">
                                                            </div>
                                                            <div class="input-field col m6 s12">
                                                                <label for="firstName">Home Address</label>
                                                                <input id="address" name="address" type="text" value="<?php echo e($data->RESIDENTIAL_ADDRESS); ?>" class="required validate">
                                                            </div>
                                                            <div class="input-field col s12">
                                                               <?php echo Form::select('religion',$religion,old('religion',''),array("required"=>"required", "tabindex"=>"-1", "v-model"=>"religion","v-form-ctrl"=>"","style"=>"width: 100%","v-select"=>"religion")   ); ?>

                                                            </div>
                                                            <div class="input-field col s12">
                                                                <div class="switch m-b-md">
                                                                    <label>
                                                                        <?php if($data->BOND!=""): ?>
                                                                        <input type="checkbox" name="bond" value="Yes" checked="">
                                                                        <?php else: ?>
                                                                         <input type="checkbox" name="bond" value="Yes" >
                                                                         <?php endif; ?>
                                                                        <span class="lever"></span>
                                                                       Are you bonded to any organization??
                                                                    </label>
                                                                </div>
                                                            </div>
                                                             
                                                        </div>
                                                    </div>
                                                    <div class="col m6">
                                                        <div class="row">
                                                            <div class="input-field col  s12">
                                                          <?php echo Form::select('region',$region ,array('placeholder'=>'select region',"required"=>"required", "tabindex"=>"-1","id"=>"region","v-model"=>"region","v-form-ctrl"=>"","v-select"=>"<?php echo e(old('region')); ?>")   ); ?>    
                                                            </div>
                                                             <div class="input-field col  s12">
                                                                   <?php echo Form::select('nationality',$country ,array('placeholder'=>'select nationality',"required"=>"required", "tabindex"=>"-1","v-model"=>"nationality","v-form-ctrl"=>"","style"=>"width: 100%","v-select"=>"nationality")   ); ?>

                                                             
                                                             </div>
                                                            <div class="input-field col  s12">
                                                                <?php echo Form::select('halls',$hall,array('placeholder'=>'select hall of choice',"required"=>"required",  "id"=>"halls","v-model"=>"halls","v-form-ctrl"=>"","v-select"=>"halls")   ); ?>

                                                             
                                                            </div>
                                                            <div class="input-field col m6 s12">
                                                                <label for="city">Email</label>
                                                                <input  id="email" name="email" type="email" value="<?php echo e($data->EMAIL); ?>" class="required validate">
                                                            </div>
                                                            <div class="input-field col s12">
                                                            <?php echo Form::select('disability',array("Yes"=>"Yes","No"=>"No"),old('disability',''),array('placeholder'=>'Select disability',"required"=>"required","tabindex"=>"-1")); ?>

                                                           
                                                            </div>
                                                             
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </section>
                                        <h3>Page 3 - Guardian Info</h3>
                                        <section>
                                            <div class="wizard-content">
                                                  <div class="row">
                                                    <div class="col m6">
                                                        <div class="row">
                                                             <div class="input-field col s12">
                                                                <label for="firstName">Guardian Name</label>
                                                                <input id="gname" name="gname" type="text" value="<?php echo e($data->GURDIAN_NAME); ?>" class="required validate">
                                                            </div>
                                                             <div class="input-field col s12">
                                                                <label for="firstName">Guardian Address</label>
                                                                <input id="gaddress" name="gaddress" type="text" value="<?php echo e($data->GURDIAN_ADDRESS); ?>" class="required validate">
                                                            </div>
                                                            
                                                            <div class="input-field col m6 s12">
                                                                <label for="firstName">Source of Finance</label>
                                                                <input id="finance" name="finance" type="text" value="<?php echo e($data->SOURCE_OF_FINANCE); ?>" class="required validate">
                                                            </div>
                                                             
                                                             
                                                        </div>
                                                    </div>
                                                    <div class="col m6">
                                                        <div class="row">
                                                           <div class="input-field col m6 s12">
                                                                <label for="lastName">Relationship to Guardian</label>
                                                                <input id="grelationship" name="grelationship" type="text" value="<?php echo e($data->RELATIONSHIP_TO_APPLICANT); ?>" class="required validate">
                                                            </div>
                                                             
                                                           <div class="input-field col m6 s12">
                                                                <label for="firstName">Guardian Occupation</label>
                                                                <input id="goccupation" name="goccupation" type="text" value="<?php echo e($data->GURDIAN_OCCUPATION); ?>"class="required validate">
                                                            </div>
                                                            
                                                              <div class="input-field col  m6 s12">
                                                                <label for="phone">Guardian Phone</label>
                                                                <input id="gphone" name="gphone" minlength="10" pattern='^[0-9]{10}$' value="<?php echo e($data->GURDIAN_PHONE); ?>"   maxlength="10"type="number" class="required validate">
                                                            </div>
                                                             
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </section>
                                        <h3>Page 4 - Choice of Programme</h3>
                                        <section>
                                            <div class="wizard-content">
                                               <div class="row">
                                                    <div class="col m6">
                                                        <div class="row">
                                                             <div class="input-field col s12">
                                                                 <?php echo Form::select('firstChoice',$programme ,array('placeholder'=>'select first choice',"required"=>"required","style"=>"width: 100%","class"=>"js-states browser-default", "tabindex"=>"-1","v-model"=>"programme","v-form-ctrl"=>"","v-select"=>"first")   ); ?>

                                                            </div>
                                                             <div class="input-field col s12">
                                                                 <?php echo Form::select('secondChoice',$programme ,array('placeholder'=>'select second choice',"required"=>"required","style"=>"width: 100%","class"=>"js-states browser-default", "tabindex"=>"-1","v-model"=>"programme","v-form-ctrl"=>"","v-select"=>"third")   ); ?>

                                                            </div>
                                                            
                                                            
                                                             
                                                             
                                                        </div>
                                                    </div>
                                                    <div class="col m6">
                                                        <div class="row">
                                                           <div class="input-field col   s12">
                                                                 
                                                                 <?php echo Form::select('thirdChoice',$programme ,array('placeholder'=>'select third choice',"required"=>"required","style"=>"width: 100%","class"=>"js-states browser-default", "tabindex"=>"-1","style"=>"width: 100%")   ); ?>

                                                             
                                                           </div>
                                                             
                                                             <div class="input-field col m6 s12">
                                                                <label for="firstName">Programme Study at school</label>
                                                                <input id="programStudy" name="study_program" type="text" value="<?php echo e($data->PROGRAMME_STUDY); ?>" class="required validate">
                                                            </div>
                                                             <div class="input-field col m6 s12">
                                                                <label for="firstName">Former SHS (School)</label>
                                                                <input id="school" name="school" type="text" value="<?php echo e($data->SCHOOL); ?>" class="required validate">
                                                            </div>
                                                             
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </section>
                                    </div>
                                </form>
            </div>
        </div>
    </div>
</div>
</main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
  
<script src="<?php echo url('public/assets/plugins/jquery-steps/jquery.steps.min.js'); ?>"></script>
        <script src="<?php echo url('public/assets/plugins/jquery-validation/jquery.validate.min.js'); ?>"></script>
        <script src="<?php echo url('public/assets/js/pages/form-wizard.js'); ?>"></script>
    
 <script>

//code for ensuring vuejs can work with select2 select boxes
Vue.directive('select', {
  twoWay: true,
  priority: 1000,
  params: [ 'options'],
  bind: function () {
    var self = this
    $(this.el)
      .select2({
        data: this.params.options,
         width: "resolve"
      })
      .on('change', function () {
        self.vm.$set(this.name,this.value)
        Vue.set(self.vm.$data,this.name,this.value)
      })
  },
  update: function (newValue,oldValue) {
    $(this.el).val(newValue).trigger('change')
  },
  unbind: function () {
    $(this.el).off().select2('destroy')
  }
})


var vm = new Vue({
  el: "body",
  ready : function() {
  },
 data : {
   title:"<?php echo $data->TITLE ?>",
  firstChoice:"<?php echo $data->FIRST_CHOICE ?>",
  secondChoice:"<?php echo $data->SECOND_CHOICE ?>",
   thirdChoice:"<?php echo $data->THIRD_CHOICE ?>",
  gender:"<?php echo $data->GENDER?>",
  nationality:"<?php echo $data->NATIONALITY ?>",
  religion:"<?php echo $data->RELIGION ?>",
  region:"<?php echo $data->REGION ?>",
  qualification:"<?php echo $data->ENTRY_QUALIFICATION ?>",
  
  
    
 options: [      
    ],
     
  },
  methods : {
     
      
     
  }
})

</script>
<!--         <script src="<?php echo url('public/assets/plugins/select2/js/select2.min.js'); ?>"></script>
        <script src="<?php echo url('public/assets/js/pages/form-select2.js'); ?>"></script>
       -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>