 
<?php $__env->startSection('style'); ?>
 
<?php $__env->stopSection(); ?>
 <?php $__env->startSection('content'); ?>
   <div class="md-card-content">
<?php if(Session::has('success')): ?>
            <div style="text-align: center" class="uk-alert uk-alert-success" data-uk-alert="">
                <?php echo Session::get('success'); ?>

            </div>
 <?php endif; ?>
 
     <?php if(count($errors) > 0): ?>

    <div class="uk-form-row">
        <div class="uk-alert uk-alert-danger" style="background-color: red;color: white">

              <ul>
                <?php foreach($errors->all() as $error): ?>
                  <li> <?php echo e($error); ?> </li>
                <?php endforeach; ?>
          </ul>
    </div>
  </div>
<?php endif; ?>
  </div>
 
 <h5>Grading System Categories</h5>
 <div class="uk-width-xLarge-1-1">
    <div class="md-card">
        <div class="md-card-content">
      
             <div class="uk-overflow-container">
           <center><span class="uk-text-success uk-text-bold"><?php echo $data->total(); ?> Records</span></center>
       
           <table class="uk-table uk-table-align-vertical uk-table-nowrap tablesorter tablesorter-altair" id="ts_pager_filter">                     <thead>
               <thead>
                   <tr>

                       <th>NO</th>
                       <th>NAME</th> 
 
                       <th>ACTION</th>
 
                   </tr>
               </thead>
               <tbody>

                   <?php foreach($data as $index=> $row): ?> 

                   <tr align="">

                       <td> <?php echo e($data->perPage()*($data->currentPage()-1)+($index+1)); ?> </td>

                       <td> <?php echo e(@$row->type); ?></td> 

                       <td>


<!--                           <?php echo Form::open(['action' =>['GradeController@destroy', 'id'=>$row->id], 'method' => 'DELETE','name'=>'myform' ,'style' => 'display: inline;']); ?>


                           <button type="submit" onclick="return confirm('Are you sure you want to delete this fee component??')" class="md-btn  md-btn-danger md-btn-small   md-btn-wave-light waves-effect waves-button waves-light" ><i  class="sidebar-menu-icon material-icons md-18">delete</i></button>

                           <?php echo Form::close(); ?>-->

                            <a href=""><i class="md-icon material-icons">&#xE254;</i></a>
                            <a href='<?php echo e(url("/grade_system/$row->type/slug")); ?>'><i class="md-icon material-icons">&#xE88F;</i></a>

                       </td>

                   </tr>
                   <?php endforeach; ?>
               </tbody>

           </table>
           
          <?php echo (new Landish\Pagination\UIKit($data->appends(old())))->render(); ?>

     </div>
<div class="md-fab-wrapper">
        <a class="md-fab md-fab-small md-fab-accent md-fab-wave" href="<?php echo url('/create_grade'); ?>">
            <i class="material-icons md-18">&#xE145;</i>
        </a>
    </div>
 </div>
    </div>
 </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
 
<script>
    
 
 var oTable = $('#gad').DataTable({
     
        
        processing: true,
        serverSide: true,
        ajax: {
            url:  "<?php echo route('programmes.data'); ?>"
             
        },
        columns: [
        {data: 'ID', name: 'ID'},
            
            {data: 'DEPTCODE', name: 'DEPTCODE'},
            {data: 'PROGRAMMECODE', name: 'PROGRAMMECODE'},
            {data: 'PROGRAMME', name: 'PROGRAMME'},
            {data: 'AFFILAITION', name: 'AFFILAITION'},
            {data: 'DURATION', name: 'DURATION'},
          
              {data: 'MINCREDITS', name: 'MINCREDITS'},
               {data: 'MAXI_CREDIT', name: 'MAXI_CREDIT'},
            {data: 'action', name: 'action', orderable: false, searchable: false}
        ]
    });
    

    
</script>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>