# Laravel Quickstart - Intermediate - Task List With Authentication

http://laravel.com/docs/quickstart-intermediate
